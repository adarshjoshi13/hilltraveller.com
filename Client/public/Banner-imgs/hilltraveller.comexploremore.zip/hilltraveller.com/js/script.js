// Load More js script start

$(document).ready(function() {
    $(".load").slice(0, 3).show();
    $("#seeMore").click(function(e) {
        e.preventDefault();
        $(".load:hidden").slice(0, 1).fadeIn("slow");

        if ($(".load:hidden").length == 0) {
            $("#seeMore").fadeOut("slow");
        }
    });
})
// Load More js script js end


// Banner Slider start 
var menu = [];
jQuery('.swiper-slide').each(function(index) {
    menu.push(jQuery(this).find('.slide-inner').attr("data-text"));
});
var interleaveOffset = 0.5;
var swiperOptions = {
    loop: true,
    speed: 1000,
    parallax: true,
    autoplay: {
        delay: 6500,
        disableOnInteraction: false,
    },
    watchSlidesProgress: true,
    pagination: {
        el: '.swiper-pagination',
        clickable: true,
    },

    navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
    },

    on: {
        progress: function() {
            var swiper = this;
            for (var i = 0; i < swiper.slides.length; i++) {
                var slideProgress = swiper.slides[i].progress;
                var innerOffset = swiper.width * interleaveOffset;
                var innerTranslate = slideProgress * innerOffset;
                swiper.slides[i].querySelector(".slide-inner").style.transform =
                    "translate3d(" + innerTranslate + "px, 0, 0)";
            }
        },

        touchStart: function() {
            var swiper = this;
            for (var i = 0; i < swiper.slides.length; i++) {
                swiper.slides[i].style.transition = "";
            }
        },

        setTransition: function(speed) {
            var swiper = this;
            for (var i = 0; i < swiper.slides.length; i++) {
                swiper.slides[i].style.transition = speed + "ms";
                swiper.slides[i].querySelector(".slide-inner").style.transition =
                    speed + "ms";
            }
        }
    }
};

var swiper = new Swiper(".swiper-container", swiperOptions);

var sliderBgSetting = $(".slide-bg-image");
sliderBgSetting.each(function(indx) {
    if ($(this).attr("data-background")) {
        $(this).css("background-image", "url(" + $(this).data("background") + ")");
    }
});

// Banner Slider end 

// inspired slider script start 

$('.inspired-slider-wrp').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    prev: true,
    next: true,
    dot: true,
    autoplay: true,
    autoplayTimeout: 3000,
    autoplayHoverPause: true,
    smartSpeed: 1500,
    navText: ['<span class="fas fa-solid fa-arrow-left "></span>', '<span class="fas fa-solid fa-arrow-right "></span>'],
    responsive: {
        0: {
            items: 2
        },
        600: {
            items: 3
        },
        1000: {
            items: 3
        }
    }
});

// inspired slider script end 


// header toggle script start 

document.getElementById('menu-toggle')
    .addEventListener('click', function() {
        document.body.classList.toggle('nav-open');
    });

// header toggle script end 


// why choose us slider 

$(' .choose-us-slider').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    prev: true,
    next: true,
    dot: true,
    // autoplay: false,
    // autoplayTimeout: 3000,
    // autoplayHoverPause: true,
    smartSpeed: 1500,
    navText: ['<span> <img src="img/choose-arrow-left.png" alt=""></span>', '<span> <img src="img/choose-arrow-right.png" alt=""> </span>'],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 2
        },
        1000: {
            items: 4
        }
    }
});

// why choose us end 


// happy customer silder start

$('.happy-customer-slider').owlCarousel({
    loop: true,
    margin: 10,
    nav: false,
    prev: true,
    next: true,
    dot: true,
    // autoplay: true,
    // autoplayTimeout: 3000,
    // autoplayHoverPause: true,
    smartSpeed: 1500,
    navText: ['<span> <img src="img/image\ 3.png" alt=""></span>', '<span> <img src="img/image\ 2.png" alt=""> </span>'],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 1
        },
        1000: {
            items: 1
        }
    }
});
// happy customer silder end



// top-places-sliderr start

$('.top-places-slider').owlCarousel({
    loop: true,
    margin: 30,
    nav: false,
    prev: true,
    next: true,
    dot: true,
    smartSpeed: 1500,
    navText: ['<span> <img src="img/image\ 3.png" alt=""></span>', '<span> <img src="img/image\ 2.png" alt=""> </span>'],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 3
        }
    }
})
// top-places-slider end


// AOS Animation script start 

AOS.init({
    duration: 1200,
    offset: 100,
    once: true,
    disable: function() {
        var maxWidth = 800;
        return window.innerWidth < maxWidth;
    }
});

// AOS Animation script end 


//  header search script  start 

document.addEventListener('click', e => {
    const toggle = document.querySelector('.search__toggle');
    const input = document.querySelector('.search__input');
    const clickedElement = e.target;

    if (clickedElement == toggle) {
        input.value = '';
        return;
    }

    const isSearchField = clickedElement.closest('.search__field');

    if (!isSearchField) {
        toggle.checked = false;
        input.value = '';
    }
});

//  header search script end 


// popular_destination_slider start 

$('.popular_destination_slider').owlCarousel({
    loop: true,
    margin: 20,
    nav: false,
    prev: true,
    next: true,
    dot: true,
    smartSpeed: 1500,
    navText: ['<span> <img src="img/image\ 3.png" alt=""></span>', '<span> <img src="img/image\ 2.png" alt=""> </span>'],
    responsive: {
        0: {
            items: 2
        },
        600: {
            items: 3
        },
        1000: {
            items: 3
        }
    }
});


// Hotel slider start 

$('.hotel_slider').owlCarousel({
    loop: true,
    margin: 20,
    nav: false,
    prev: true,
    next: true,
    dot: true,
    smartSpeed: 1500,
    navText: ['<span> <img src="img/image\ 3.png" alt=""></span>', '<span> <img src="img/image\ 2.png" alt=""> </span>'],
    responsive: {
        0: {
            items: 1
        },
        600: {
            items: 3
        },
        1000: {
            items: 3
        }
    }
});

// active bg script start 

var selector = '.itineary_tab li a';

$(selector).on('click', function() {
    $(selector).removeClass('active');
    $(this).addClass('active');
});

// The function toggles more (hidden) text when the user clicks on "Read more". The IF ELSE statement ensures that the text 'read more' and 'read less' changes interchangeably when clicked on.
$('.moreless-button').click(function() {
    $('.moretext').slideToggle();
    if ($('.moreless-button').text() == "Read more...") {
        $(this).text("Read less")
    } else {
        $(this).text("Read more...")
    }
});

// from slider script start 

initMultiStepForm();

function initMultiStepForm() {
    const progressNumber = document.querySelectorAll(".step").length;
    const slidePage = document.querySelector(".slide-page");
    const submitBtn = document.querySelector(".submit");
    const progressText = document.querySelectorAll(".step p");
    const progressCheck = document.querySelectorAll(".step .check");
    const bullet = document.querySelectorAll(".step .bullet");
    const pages = document.querySelectorAll(".page");
    const nextButtons = document.querySelectorAll(".next");
    const prevButtons = document.querySelectorAll(".prev");
    const stepsNumber = pages.length;

    if (progressNumber !== stepsNumber) {
        console.warn(
            "Error, number of steps in progress bar do not match number of pages"
        );
    }

    document.documentElement.style.setProperty("--stepNumber", stepsNumber);

    let current = 1;

    for (let i = 0; i < nextButtons.length; i++) {
        nextButtons[i].addEventListener("click", function(event) {
            event.preventDefault();

            inputsValid = validateInputs(this);
            // inputsValid = true;

            if (inputsValid) {
                slidePage.style.marginLeft = `-${(100 / stepsNumber) * current
          }%`;
                bullet[current - 1].classList.add("active");
                progressCheck[current - 1].classList.add("active");
                progressText[current - 1].classList.add("active");
                current += 1;
            }
        });
    }

    for (let i = 0; i < prevButtons.length; i++) {
        prevButtons[i].addEventListener("click", function(event) {
            event.preventDefault();
            slidePage.style.marginLeft = `-${(100 / stepsNumber) * (current - 2)
        }%`;
            bullet[current - 2].classList.remove("active");
            progressCheck[current - 2].classList.remove("active");
            progressText[current - 2].classList.remove("active");
            current -= 1;
        });
    }
    submitBtn.addEventListener("click", function() {
        bullet[current - 1].classList.add("active");
        progressCheck[current - 1].classList.add("active");
        progressText[current - 1].classList.add("active");
        current += 1;
        setTimeout(function() {
            alert("Your Form Successfully Signed up");
            location.reload();
        }, 800);
    });

    function validateInputs(ths) {
        let inputsValid = true;

        const inputs =
            ths.parentElement.parentElement.querySelectorAll("input");
        for (let i = 0; i < inputs.length; i++) {
            const valid = inputs[i].checkValidity();
            if (!valid) {
                inputsValid = false;
                inputs[i].classList.add("invalid-input");
            } else {
                inputs[i].classList.remove("invalid-input");
            }
        }
        return inputsValid;
    }
};

// from slider script end 

// dropdown select script start 

new Choices(document.querySelector(".choices-single"));
new Choices(document.querySelector(".choices-two"));


// dropdown select script end 

// datepicker script start 

var date = new Date();
date.setDate(date.getDate());

$('#date').datepicker({
    startDate: date
});

var date = new Date();
date.setDate(date.getDate());

$('#date2').datepicker({
    startDate: date
});

// datepicker script end 

jQuery(document).ready(function($) {

    window.onload = function() {
        $(".bts-popup").delay(1000).addClass('is-visible');
    }

    //open popup
    $('.bts-popup-trigger').on('click', function(event) {
        event.preventDefault();
        $('.bts-popup').addClass('is-visible');
    });

    //close popup
    $('.bts-popup').on('click', function(event) {
        if ($(event.target).is('.bts-popup-close') || $(event.target).is('.bts-popup')) {
            event.preventDefault();
            $(this).removeClass('is-visible');
        }
    });
    //close popup when clicking the esc keyboard button
    $(document).keyup(function(event) {
        if (event.which == '27') {
            $('.bts-popup').removeClass('is-visible');
        }
    });
});