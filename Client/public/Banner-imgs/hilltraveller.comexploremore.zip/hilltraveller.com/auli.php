
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>hilltraveller</title>

  <!-- bootstrap css  -->
  <link href="css/bootstrap-min.css" rel="stylesheet">

  <!-- fontawesome  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" />

  <!-- owl carousel css   -->
  <link rel="stylesheet" href="css/owl.carousel.min.css">

  <!-- swiper css-->
  <link rel='stylesheet' href='css/swiper-min.css'>

  <!-- choice select search dropdown  -->
  <link rel="stylesheet" href="css/choice-select-min.css" />

  <!-- datepicker  -->
  <link rel='stylesheet' href='css/datepicker.css'>

  <!-- Aos Animation  -->
  <link rel="stylesheet" href="css/aos.css" />

  <!-- custom css  -->
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/responsive.css">
<style>.modal-footer  > [data-dismiss="modal"]{
	margin-left:5px;
}
</style>

</head>

<body data-aos="fade-in">

  <!-- hilltraveller header start  -->

  <header>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <nav class="navbar navbar-expand-md ">
            <div class="container-fluid">
              <a class="navbar-brand d-md-none" href="https://hilltraveller.com/">
                <img src="img/logo.png" alt="">
              </a>
              <div class="search_toggle_head">
                <form class="search">
                  <input type="checkbox" id="toggleSearch" class="search__toggle" hidden />
                  <div class="search__field">
                    <label for="toggleSearch" class="search__label">
                      <span class="search__close"></span>
                    </label>
                    <input type="text" class="search__input" placeholder="search by location" />
                    <label for="toggleSearch" class="search__label">
                      <div class="search__button">
                        <i class="fa-solid fa-magnifying-glass"></i>
                      </div>
                      <button class="search__button search__button--submit">
                        <i class="fa-solid fa-magnifying-glass"></i>
                      </button>
                    </label>
                  </div>
                </form>
                <a id="menu-toggle" class="menu-toggle navbar-toggler" type="button" data-bs-toggle="collapse"
                  data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                  aria-label="Toggle navigation">
                  <span class="menu-toggle-bar menu-toggle-bar--top"></span>
                  <span class="menu-toggle-bar menu-toggle-bar--middle"></span>
                  <span class="menu-toggle-bar menu-toggle-bar--bottom"></span>
                </a>
              </div>    


              <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto">
                  <a class="navbar-brand d-none d-md-block" href="https://hilltraveller.com/">
                    <img src="img/logo.png" alt="">
                  </a>
                 
                  <li class="nav-item">
                    <a class="nav-link " aria-current="page" href="destination.php">Destinations</a>
                  </li>

                  <li class="nav-item">
                    <a class="nav-link " aria-current="page" href="chardam.php">Char Dham</a>
                  </li>
                  
                  <li class="nav-item">
                    <a class="nav-link" href="blog.php">Blogs</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="faq.php">FAQs</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" href="contact-us.php">Contact</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link contact_no" href="tel:+919579161741 ">+91- 9579161741 </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link enquire" href="#" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@fat">Enquiry Now </a>
                  </li>
                  
                </ul>
              </div>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- hilltraveller header end  -->

  
    <!-- itineraries banner section start  -->

    <section class="itineraries_banner">
        <div class="itineraries_parent">
            <img src="img/auli-banner.jpg" alt="">
            <div class="experience-banner-heading" data-aos="zoom-in">
                <h1>Auli</h1>
            </div>
        </div>
    </section>

    <!-- itineraries banner section end  -->


    <!-- munnar with us section start  -->

    <section class="munnar_us">
        <div class="container" data-aos="fade-up">
            <div class="row flex_direction">
                <div class="col-lg-5">
                    <div class="munnar_img_wrp">
                        <div class="munnar_img">
                            <img src="img/way-of-Auli.jpg" alt="">
                        </div>
                       <!--  <div class="munnar_play_icon">
                            <a href="#"><img src="img/itineraries-details/play_icon.png" alt=""></a>
                        </div> -->
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="why_munnar_parent">
                        <div class="why_munnar_wrp">
                            <div class="heading">
                                <h2>Why you should travel
                                    Auli with us?</h2>
                            </div>
                        </div>
                        <div class="article why_munnar_pera">
                            <p>Auli, a haven for biking aficionados, unveils spellbinding mountain biking trails, ideal for a summer dirt-off escapade. Take your adventure to new heights with the exhilarating 4 km Gondola or cable car journey, providing a panoramic spectacle of Auli's enchanting resort landscape. Beyond the thrill of biking and scenic rides, Auli entices visitors with must-see attractions, including the captivating Artificial Lake. Positioned strategically, each spot promises a unique and immersive experience, solidifying Auli as a multifaceted destination where adventure seamlessly intertwines with natural beauty. In 2011, Auli, Uttarakhand, made history as the prestigious host of the inaugural South Asian Winter Games. Elevating the event to international standards, French and Austrian experts spearheaded the organization, bringing their unparalleled expertise to ensure a seamlessly executed and unforgettable sporting spectacle in the heart of the Himalayas.</p>
                            <p class="moretext">
                            Auli, a gem among the world's top ski resorts, invites you to elevate your skiing prowess. During your week-long sojourn, seize the opportunity to enroll in the GMVN's meticulously curated 7 or 14-day ski courses, personally guided by seasoned experts. This exclusive experience promises not just adventure but a transformative journey into the art of skiing. Tailored provisions for day tourists ensure that everyone, from novices to enthusiasts, can savor the exhilaration of Auli's world-class skiing adventures. </p>
                        </div>
                        <a class="moreless-button" href="javascript:void(0)">Read more...</a>



                        <div class="why_munnar_flex">
                            <div class="munnar_child">
                                <div class="munnar_icon">
                                    <img src="img/itineraries-details/best_time_visit.png" alt="">
                                </div>
                                <div class="munnar_bottom_text">
                                    <p>Best Time</p>
                                </div>
                            </div>
                            <div class="munnar_child">
                                <div class="munnar_icon">
                                    <img src="img/itineraries-details/climate.png" alt="">
                                </div>
                                <div class="munnar_bottom_text">
                                    <p>Climate</p>
                                </div>
                            </div>
                            <div class="munnar_child">
                                <div class="munnar_icon">
                                    <img src="img/itineraries-details/cuisine.png" alt="">
                                </div>
                                <div class="munnar_bottom_text">
                                    <p>Cuisine</p>
                                </div>
                            </div>

                            <div class="munnar_child">
                                <div class="munnar_icon">
                                    <img src="img/itineraries-details/language.png" alt="">
                                </div>
                                <div class="munnar_bottom_text">
                                    <p>Langauge</p>
                                </div>
                            </div>

                            <div class="munnar_child">
                                <div class="munnar_icon">
                                    <img src="img/itineraries-details/geography.png" alt="">
                                </div>
                                <div class="munnar_bottom_text">
                                    <p>Geography</p>
                                </div>
                            </div>
                            <div class="munnar_child">
                                <div class="munnar_icon">
                                    <img src="img/itineraries-details/population.png" alt="">
                                </div>
                                <div class="munnar_bottom_text">
                                    <p>Population</p>
                                </div>
                            </div>
                        </div>
                        <div class="enquiry_btn">
                            <a data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@fat"
                                href="#">Enquire Now <i class="fa-solid fa-arrow-right"></i></a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>

    <!-- munnar with us section end  -->

    <!-- itinearies tab section start  -->
    <section class="itinerery_tab">
        <div class="container" data-aos="zoom-in">
            <div class="row">
                <div class="itineary_tab">
                    <ul>
                        <li><a class="active" href="#itinearies">Itineraries</a></li>
                        <li><a href="#place-interset">Places of Intrest</a></li>
                        <li><a href="#hotels">Hotels</a></li>
                        <li><a href="#clients">What our clients says</a></li>
                        <li><a href="#faq">FAQs</a></li>
                        <li><a href="#">Blogs</a></li>

                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- itinearies tab section end  -->


    <!-- Day Itineraries section  start  -->

    <section class="day_itinearies" id="itinearies">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="heading">
                        <h2>Day Itineraries <img class="red_circle" src="img/itineraries-listing/circle_red.png" alt="">
                        </h2>
                    </div>
                </div>
            </div>
            <div class="row align-items-end flex_direction">
                <div class="col-lg-6 col-sm-6" data-aos="fade-up">
                    <div class="day_itineary_img">
                        <img src="img/auli1.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-sm-6" data-aos="fade-down">
                    <div class="day_itineary_parent">

                        <div class="heading">
                            <h3>Day 01</h3>
                        </div>
                        <div class="sub_heading">
                            <h6>Rishikesh  To Auli </h6>
                            <p>Start your Auli adventure with an early morning bus ride for a scenic experience. Alternatively, opt for a direct cab to Auli for personalized comfort. For a balanced approach, take a bus to Joshimath and seamlessly transition to a cab for the final leg of your journey, offering both adventure and convenience.</p>
                        </div>

                        <div class="day_itineary_pera">
                            <p>You can also take small walks around the property. Enjoy the evening with tea followed by dinner. </p>
                        </div>

                    </div>
                </div>
            </div>
            <div class="row align-items-end">

                <div class="col-lg-6 col-sm-6" data-aos="fade-down">
                    <div class="day_itineary_parent new_parent">

                        <div class="heading">
                            <h3>Day 02 - 03</h3>
                        </div>
                        <div class="sub_heading">
                            <h6>In Auli </h6>
                            <p>Experience Auli's charm with the serene Auli Lake, picturesque Chenab Lake, and the lush meadows of Garson Bugyal. Elevate your adventure with the Char-lift and embrace the thrill of skiing. Auli offers a delightful mix of tranquility and excitement for a unique getaway.</p>
                        </div>

                        <div class="day_itineary_pera">
                            <p>Start your day with a hearty breakfast, gearing up for an exhilarating skiing experience in Auli. Ascend with the cable car, soaking in the mesmerizing Auli scenery. A short walk will lead you to the skiing point, where beginners receive expert guidance on mastering the basics. Today promises a blend of breathtaking landscapes and the thrill of learning a new skill on the snowy slopes of Auli.<p>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6 col-sm-6" data-aos="fade-up">
                    <div class="day_itineary_img">
                        <img src="img/auli3.jpg" alt="">
                    </div>
                </div>
            </div>
            <div class="row align-items-end flex_direction">
                <div class="col-lg-6 col-sm-6" data-aos="fade-up">
                    <div class="day_itineary_img">
                        <img src="img/auli2.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6 col-sm-6" data-aos="fade-down">
                    <div class="day_itineary_parent">

                        <div class="heading">
                            <h3>Day 04</h3>
                        </div>

                        <div class="sub_heading">
                            <h6>Departure from Auli. </h6>
                            
                        </div>
                        <div class="day_itineary_pera">
                            <p>Begin your day in Auli with a delightful early morning breakfast before embarking on your journey to Rishikesh. Once in Rishikesh, savor a satisfying dinner, immersing yourself in the spiritual vibes of this vibrant town. Conclude your adventure with a night bus ride to Delhi, allowing you to reflect on the memories made during your picturesque retreat in the Himalayas. </p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Day Itineraries section  end  -->


    <!-- make this itinearies section start  -->

      <!-- make this itinearies section start  -->

    <section class="make_itinearies new_itinearies">
        <div class="container" data-aos="fade-up">
            <div class="row align-items-center justify-content-center">
                <div class="col-lg-11 col-sm-12">
                    <div class="row align-items-center ">
                        <div class="col-lg-5 col-sm-5">
                            <div class="make_heading">
                                <h4>Make this destination yours!</h4>
                            </div>
                            <div class="make_pera">
                                <p>Unveil the beauty of iconic landmarks, relish gourmet delights, and be pampered with
                                    impeccable hospitality. </p>
                            </div>
                        </div>
                        <div class="col-lg-7 col-sm-7">
                            <div class="call_us_btn">
                                <a href="tel:+919579161741"><i class="fa-solid fa-phone"></i> Call Now: +91 95xxxxxxx</a>
                                <a data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@fat"
                                    href="#">Enquire Now <i class="fa-solid fa-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- make this itinearies section end  -->
    <!-- make this itinearies section end  -->
    <!-- top places of kerala section start  -->
    <section class="top_places" id="place-interset">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="heading">
                        <h2>Most Visited Destination <img class="red_circle" src="img/itineraries-listing/circle_red.png"
                                alt=""></h2>
                        <p>If we were asked to choose our top places in Himalayan haven in Uttarakhand, we’d go for these.</p>
                    </div>
                </div>
            </div>

            <div class=" top-places-slider owl-carousel owl-theme">

                <div class="places_head" data-aos="fade-down">
                    <div class="place_item_parent">
                        <div class="places_child">
                            <div class="places_img">
                                <img src="img/destination/Auli.jpg" alt="">
                            </div>
                            <div class="bottom_head">
                                <h6>Auli</h6>
                            </div>
                        </div>
                        <div class="place_bottom_text">

                            <p>Auli, a Himalayan haven in Uttarakhand, enchants with emerald tea gardens and awe-inspiring panoramas of snow-draped peaks. A picturesque retreat, inviting serenity and embracing nature's timeless beauty.</p>
                            <div class="read_more_btn">
                                <a href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="places_head" data-aos="fade-down">
                    <div class="place_item_parent">
                        <div class="places_child">
                            <div class="places_img">
                                <img src="img/destination/Chaukori.jpg" alt="">
                            </div>
                            <div class="bottom_head">
                                <h6>Chaukori</h6>
                            </div>
                        </div>
                        <div class="place_bottom_text">

                            <p>Chaukori, a Himalayan haven in Uttarakhand, enchants with emerald tea gardens and awe-inspiring panoramas of snow-draped peaks. A picturesque retreat, inviting serenity and embracing nature's timeless beauty.</p>
                            <div class="read_more_btn">
                                <a href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="places_head" data-aos="fade-up">
                    <div class="place_item_parent">
                        <div class="places_child">
                            <div class="places_img">
                                <img src="img/destination/Nainital.jpg" alt="">
                            </div>
                            <div class="bottom_head">
                                <h6>Nainital</h6>
                            </div>
                        </div>
                        <div class="place_bottom_text">

                            <p>Nainital, nestled around the scenic Naini Lake, captivates with its lush landscapes, vibrant markets, and cultural richness. Explore the town's charm, viewpoints, and temples for a delightful Himalayan experience.</p>
                            <div class="read_more_btn">
                                <a href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="places_head" data-aos="fade-down">
                    <div class="place_item_parent">
                        <div class="places_child">
                            <div class="places_img">
                                <img src="img/destination/Dhanouti.jpg" alt="">
                            </div>
                            <div class="bottom_head">
                                <h6>Dhanouti </h6>
                            </div>
                        </div>
                        <div class="place_bottom_text">
                            <p>Dhanaulti, a Himalayan gem in Uttarakhand, invites with tranquil pine forests and panoramic vistas. Delight in serene eco-parks and adventure pursuits, creating a perfect haven for nature enthusiasts and thrill-seekers alike</p>
                            <div class="read_more_btn">
                                <a href="#">Read More</a>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="view-all-btn text-center">
                        <a href="destination.html">View All <i class="fa-solid fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- top places of kerala section end  -->

    <!-- hotel section start  -->

    <section class="places_interset" id="hotels">
        <div class="container" data-aos="fade-up">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="heading">
                        <span>Where here to rest your head <img class="red_circle"
                                src="img/itineraries-listing/circle_red.png" alt=""></span>
                        <h2>Hotels </h2>

                    </div>
                </div>
            </div>
            <div class="hotel_slider owl-carousel owl-theme">
                <div class="places_interset_head">
                    <div class="place_img">
                        <img src="img/itineraries-details/hotel1.jpg" alt="">
                    </div>
                    <div class="places_text">
                        <h6>THE PANORAMIC GETAWAY</h6>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab deleniti sequi debitis
                            consectetur repellat. Non mollitia ab aliquam porro voluptates.</p>
                    </div>
                </div>
                <div class="places_interset_head">
                    <div class="place_img">
                        <img src="img/itineraries-details/hotel2.jpg" alt="">
                    </div>
                    <div class="places_text">
                        <h6>KTDC TEA COUNTY </h6>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab deleniti sequi debitis
                            consectetur repellat. Non mollitia ab aliquam porro voluptates.</p>
                    </div>
                </div>
                <div class="places_interset_head">
                    <div class="place_img">
                        <img src="img/itineraries-details/hotel3.jpg" alt="">
                    </div>
                    <div class="places_text">
                        <h6>TEA VALLEY RESORT</h6>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ab deleniti sequi debitis
                            consectetur repellat. Non mollitia ab aliquam porro voluptates.</p>
                    </div>
                </div>

            </div>

        </div>
    </section>

    <!-- places of interset section end  -->


    <!-- section best for you start  -->
    <section class="best-for-you">
        <div class="container" data-aos="fade-up">
            <div class="row">
                <div class="col-lg-6">
                    <div class="best-for-you-heading">
                        <div class="heading">
                            <span class="left-align">Reach Us <img class="red_circle" src="img/itineraries-listing/circle_red.png"
                                    alt=""></span>
                            <h2>Have a coffee, Let us do the best for you </h2>
                            <p>Unveil the beauty of iconic landmarks, relish gourmet delights, and be pampered with
                                impeccable
                                hospitality. Reserve your passport to unforgettable moments
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="let-us-find-form">
                        <div class="form-heading">
                            <h5>Let us Find you the Best Package!</h5>
                        </div>
                        <form action="#">
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <input type="text" placeholder="Name*" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <input type="text" placeholder="Contact no.*" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <input type="email" placeholder="Email*" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <select class="form-control choices-two form-select">
                                        <option selected> Select Destination</option>
                                        <option value="AZ">Andamans</option>
                                        <option value="CO">Kerela</option>
                                        <option value="ID">Nepal</option>
                                        <option value="MT">Sikkim</option>
                                        <option value="NE">Noth East</option>
                                        <option value="NM">Paris</option>

                                    </select>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <input type="text" placeholder="Travelling Date*" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <input type="number" placeholder="No. Of Days*" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <div class="d-flex">
                                            <div class="number">
                                                <div class="guest">
                                                    <input class="form-control" type="number" placeholder="Adult*" />
                                                </div>
                                            </div>
                                            <div class="number ">
                                                <div class="guest">
                                                    <input class="form-control" type="number" placeholder="Child*" />
                                                </div>
                                            </div>
                                            <div class="number ">
                                                <div class="guest">
                                                    <input class="form-control" type="number" placeholder="Infant*" />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="mb-3">
                                        <input type="text" placeholder="Message*" class="form-control">
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="mb-1">
                                        <div class="form-btn">
                                            <input type="submit" value="Yes, Send Me the Details! " class="form-submit">
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- section best for you end  -->
    <!-- section happy-customer start -->
    
  <!-- section happy-customer start -->

  <section class="happy-customer">
    <div class="container" data-aos="fade-up">
      <div class="row">
        <div class="col-lg-12">
          <div class="happy-customer-heading">
            <div class="heading">
              <span>TESTIMONIALS <img class="red_circle" src="img/itineraries-listing/circle_red.png" alt=""></span>
              <h2>Meet our happy customers
              </h2>
              <p>Unveil the beauty of iconic landmarks, relish gourmet delights, and be pampered with impeccable
                hospitality. Reserve your passport to unforgettable moments</p>
            </div>
          </div>
        </div>
        <div class="col-lg-12">
          <div class="happy-customer-slider-wrp">
            <div class=" happy-customer-slider owl-carousel owl-theme">
              <div class="happy-customer-parent">
                <div class="row">
                  <div class="col-lg-5 col-sm-5">
                    <div class="happy-customer-video">
                      <img src="img/ankit-testi.jpg" alt="">
                      <!-- <div class="play-icon">
                        <img src="img/video-play.png" alt="">
                      </div> -->
                    </div>
                  </div>
                  <div class="col-lg-7 col-sm-7">
                    <div class="happy-customer-info">
                      <h4>Ankit</h4>
                      <p>My pilgrimage to the Char Dham destinations in Uttarakhand was nothing short of a divine experience. The sacred sites of Yamunotri, Gangotri, Kedarnath, and Badrinath left an indelible mark on my soul. The pristine landscapes and the serenity of these holy places provided a perfect backdrop for reflection and prayer.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="happy-customer-parent">
                <div class="row">
                  <div class="col-lg-5 col-sm-5">
                    <div class="happy-customer-video">
                      <img src="img/manoj-testi.jpg" alt="">
                      <!-- <div class="play-icon">
                        <img src="img/video-play.png" alt="">
                      </div> -->
                    </div>

                  </div>
                  <div class="col-lg-7 col-sm-7">
                    <div class="happy-customer-info">
                      <h4>Manoj</h4>
                      <p>Yamunotri, nestled in the lap of the Garhwal Himalayas, captivated me with its natural beauty. The Yamuna River, originating from here, is not just a watercourse but a symbol of purity.</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="happy-customer-parent">
                <div class="row align-items-center justify-content-center">

                  <div class="col-lg-10 col-sm-10">
                    <div class="happy-customer-info happy_info_new">
                      <h4>Aman Kumar</h4>
                      <p>The entire journey was seamlessly facilitated by the efficient arrangements and guidance from the local tour operators. Their attention to detail ensured a smooth and enriching experience. </p><p>Each moment spent in Uttarakhand's Char Dham was a step closer to self-discovery and a profound connection with the divine.</p>
                      <p>Unveil the beauty of iconic landmarks, relish gourmet delights, and be pampered with impeccable
                        hospitality. Reserve your passport to unforgettable moments</p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="happy-customer-parent">
                <div class="row">
                  <div class="col-lg-5 col-sm-5">
                    <div class="happy-customer-video">
                      <img src="img/badrish.jpg" alt="">
                      <div class="play-icon">
                        <img src="img/video-play.png" alt="">
                      </div>
                    </div>

                  </div>
                  <div class="col-lg-7 col-sm-7">
                    <div class="happy-customer-info">
                      <h4>Badrish </h4>
                      <p>Kedarnath, perched at a breathtaking altitude, is a testament to unwavering faith. The trek to this holy abode is challenging but immensely rewarding. The resonating sound of bells and the mystical atmosphere are etched in my memory./p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- section happy-customer end -->
    <!-- section happy-customer end -->
    <!-- section inquirie start  -->

    <section class="inquirie">
        <div class="container" data-aos="fade-in">
            <div class="row">
                <div class="col-lg-5">
                    <div class="inquirie-heading">
                        <div class="heading">
                            <span class="left-align">FAQs <img class="red_circle" src="img/itineraries-listing/circle_red.png"
                                    alt=""></span>
                            <h2>Popular Inquiries
                            </h2>
                        </div>
                    </div>
                    <div class="view-all-btn">
                        <a href="#">View All <i class="fa-solid fa-arrow-right"></i></i></a>
                      </div>
                </div>
                <div class="col-lg-7">
                    <div class="inquirie-list">
                        <div class="accordion" id="accordionPanelsStayOpenExample">
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseOne" aria-expanded="true"
                                        aria-controls="panelsStayOpen-collapseOne">
                                        How do I book a travel package on your website?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseOne" class="accordion-collapse collapse show"
                                    aria-labelledby="panelsStayOpen-headingOne">
                                    <div class="accordion-body">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, officiis ex
                                            reprehenderit, magni
                                            voluptate sunt sapiente pariatur dolor nihil ipsam, dolore quaerat quos
                                            soluta aspernatur eligendi
                                            repudiandae deleniti sequi eveniet!</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingTwo">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseTwo" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseTwo">
                                        Can I customize a travel package according to my preferences?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseTwo" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingTwo">
                                    <div class="accordion-body">
                                        <p>Explore the "Packages" or "Tours" section.<br>Pick your preferred package, Check the details and make any customizations, 
Click on "Enquire Now.", Fill in your information, Confirm your booking, Keep the confirmation details handy.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingThree">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapseThree" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapseThree">
                                        What payment options do you accept, and is my payment secure?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapseThree" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingThree">
                                    <div class="accordion-body">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, officiis ex
                                            reprehenderit, magni
                                            voluptate sunt sapiente pariatur dolor nihil ipsam, dolore quaerat quos
                                            soluta aspernatur eligendi
                                            repudiandae deleniti sequi eveniet!</p>
                                    </div>
                                </div>
                            </div>
                            <div class="accordion-item">
                                <h2 class="accordion-header" id="panelsStayOpen-headingfour">
                                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                        data-bs-target="#panelsStayOpen-collapsefour" aria-expanded="false"
                                        aria-controls="panelsStayOpen-collapsefour">
                                        What is included in your travel packages?
                                    </button>
                                </h2>
                                <div id="panelsStayOpen-collapsefour" class="accordion-collapse collapse"
                                    aria-labelledby="panelsStayOpen-headingfour">
                                    <div class="accordion-body">
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Veniam, officiis ex
                                            reprehenderit, magni
                                            voluptate sunt sapiente pariatur dolor nihil ipsam, dolore quaerat quos
                                            soluta aspernatur eligendi
                                            repudiandae deleniti sequi eveniet!</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- section inquirie end  -->


    <!-- section subscribe start -->

    <section class="subscribe">
        <div class="container" data-aos="zoom-in">
            <div class="row">
                <div class="col-lg-12">
                    <div class="subscribe-heading">
                        <div class="heading">
                            <span>NEWSLETTERS <img class="red_circle" src="img/itineraries-listing/circle_red.png"
                                    alt=""></span>
                            <h2>Subscribe our newsletter
                            </h2>
                            <p>Don't miss out on your perfect getaway - book today!</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="subscribe-input">
                        <input type="email" placeholder="enter your mail*" class="form-control">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="subscribe-btn">
                        <input type="submit" value="Yes, send me good offers!" class="subscribe-submit">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- section subscribe end -->

    <!-- fotter start  -->

 
<hr>
<!-- fotter start  -->
  <footer>
    <div class="container" data-aos="fade-up">
      <div class="row">
        <div class="col-lg-4 col-sm-4">
          <div class="footer-data">
            <a href="index.php">
              <img src="img/logo.png" alt="" width="50%">
            </a>
            <p>hilltraveller.com  is unit of Have a Nice Trip Private Limited <p>
            <p>CIN No :- <strong>U63030UP2021PTC156433
</strong> <br>
            GST No :- <strong>09AAGCH0749G1ZJ</strong> <br>
            GST No :- <strong>AAGCH0749G </strong> </p>
          </div>
          <div class="footer-icon">
            <li><a href="https://www.facebook.com/profile.php?id=61554812941178"><i class="fa-brands fa-facebook-f"></i></a></li>
            <li><a href="https://www.instagram.com/hilltraveller_27/"><i class="fa-brands fa-instagram"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa-brands fa-youtube"></i></a></li>
          </div>
        </div>
        <div class="col-lg-4 col-sm-4">
          <div class="footer-links">
            <h5>Who we are?</h5>
            <ul>
              <li><a href="about-us.php">About us </a></li>            
              <li><a href="contact-us.php">Contact</a></li>
              <li><a href="privacypolicy.php">Privacy Policy </a></li>
              <li><a href="term-condition.php">Terms and Conditions </a></li>
              <li><a href="refund-policy.php">Refund Policy</a></li>
            </ul>
          </div>
        </div>
      
        <div class="col-lg-4 col-sm-4">
          <div class="footer-links">
            <h5>Reach Us</h5>
            <ul>
              <li><i class="fa-solid fa-phone"></i><a href="tel:01203576847">0120-3576847 </a></li>
              <li><i class="fa-solid fa-envelope"></i><a href="mailto:info@hilltraveller.com">info@hilltraveller.com</a></li>
              <li><i class="fa-solid fa-location-dot"></i><a href="#">Add-17-C-318, Ghaziabad, VASUNDHARA, Uttar Pradesh, India, 201012</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    
  </footer>
  <!-- fotter end  -->
  <div class="footer-bottom">
      <p>© 2023 hilltraveller All Right Reserved.<p> 
</div>

  <!-- end-fix-footer start  -->

  
  <div class="fix-footer-risponsive">
    <div class="icon-wrp-risponsive">
      <a href="tel:+919579161741"><img src="img/call.png" alt="" width="41"></a>
    </div>
    <div class="icon-wrp-risponsive">
      <a data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@fat" href="#"><img
          src="img/massage.png" alt="" width="41"></a>
    </div>
    <div class="icon-wrp-risponsive">
    <a href="https://api.whatsapp.com/send?l=en&amp;phone=+919582330193&amp;text=Hi..," target="_blank" data-action="share/whatsapp/share"><img src="img/whatsapp_icon.png" alt="" width="41px"> </a>
    </div>
  </div>

  <!-- end-fix-footer end  -->

  <!-- model box section start-->
    <!-- model box section start-->
  <div class="modal fade enquire_popup" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">ENQUIRE FORM</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="container my_container">
          
          <div class="form-outer">
           <form action="get-tuchus.php" method="post" role="form"
                                name="header" id="header">
              <div class="page slide-page">
                <div class="row">
                  <div class="col-lg-6">
                    <div class="field">
                      <input type="text" name="name" class="form-control" placeholder="Enter First Name" required/>
                    </div>
                  </div>
                    <div class="col-lg-6">
                    <div class="field">
                      <input type="number" name="phone" class="form-control" placeholder="Enter Your Phone No." required />
                    </div>
                  </div>
                 
                  <div class="col-lg-6">
                    <div class="field">
                      <input type="email" name="email" class="form-control" placeholder="Enter Your Email Address" required />
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="field">
                      <select class="form-control choices-single form-select" name="destination" required>
                        <option selected> Select Destination</option>
                        <option value="Rishikesh">Rishikesh</option>
                        <option value="Haridwar">Haridwar</option>
                        <option value="Chopta">Chopta</option>
                        <option value="Auli">Auli</option>
                        <option value="Nainital">Nainital</option>
                        <option value="Harsil">Harsil</option>
                        <option value="Chaukori">Chaukori</option>
                        <option value="Badrinath">Badrinath</option>
                        <option value="Kedarnath">Kedarnath</option>
                        <option value="Dhanaulti">Dhanaulti</option>
                      
                      </select>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="field">
                      <input id="date" data-provide="datepicker" name="checkindate" class="form-control"
                        placeholder="Enter Your Check In Day*" required>
                      <i data-provide="datepicker" class="fa-solid fa-calendar-days"></i>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="field">
                      <input id="date2" data-provide="datepicker"  name="checkoutdate" type="text" placeholder="Enter Your Check Out Day*"
                        class="form-control" required>
                      <i data-provide="datepicker" class="fa-solid fa-calendar-days"></i>
                    </div>
                  </div>
                 
                  <div class="col-lg-12">
                    <div class="field">
                      <div class="d-flex justify-content-between">
                        <div class="number">
                          <div class="guest">
                            <input class="form-control"  name="adult" type="number" placeholder="Adult*"  />
                          </div>
                        </div>
                        <div class="number ">
                          <div class="guest">
                            <input class="form-control"  name="child" type="number" placeholder="Child*" />
                          </div>
                        </div>
                        <div class="number ">
                          <div class="guest">
                            <input class="form-control"   name="infant" type="number" placeholder="Infant*" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="field">
                    <textarea id="story" name="msg" rows="1" class="form-control">Write something here.....</textarea>
                     </div>
                  </div>
                  <div class="col-lg-12">
                    <div class="field btns text-center">
                     
                      <input class="submit" type="submit" name="mailsent"  value="Submit">
                      
                    </div>
                  </div>
               
                </div>

              </div>
              
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- model box section end-->



  <!-- Auto Load popup -->

 <div class="bts-popup" role="alert">
 <div class="bts-popup-container">
     <div class="row">
    <div class="col-lg-6">
    <img src="img/popup-banner.jpg" />
        </div>

        <div class="col-lg-6">
          <div class="form-container">
          <form action="get-tuchus.php" method="post" role="form"
                                name="header" id="header">
          <h3> Enquier Now</h3>

          <div class="row">
    <div class="col-lg-6">
                      <input type="text" name="name" class="form-control" placeholder="Enter First Name" required />
                      </div>
                      <div class="col-lg-6">
                      <input type="number" name="phone" class="form-control" placeholder="Enter Your Phone No." required/>
                      </div>
                     
                      <br>
                      <div class="row">
                           <div class="col-lg-6">
                      <input type="email" name="email" class="form-control" placeholder="Enter Your Email Address" required />
                      </div>
                      <div class="col-lg-6">

                      <select class="form-control choices-single form-select" name="destination" required>
                        <option selected> Select Destination</option>
                        <option value="Rishikesh">Rishikesh</option>
                        <option value="Haridwar">Haridwar</option>
                        <option value="Chopta">Chopta</option>
                        <option value="Auli">Auli</option>
                        <option value="Nainital">Nainital</option>
                        <option value="Harsil">Harsil</option>
                        <option value="Chaukori">Chaukori</option>
                        <option value="Badrinath">Badrinath</option>
                        <option value="Kedarnath">Kedarnath</option>
                        <option value="Dhanaulti">Dhanaulti</option>
                      
                      </select>
                      </div>
                      </div>
                     

                      <div class="row">
                           <div class="col-lg-6">
                      <input id="date" data-provide="datepicker" name="checkindate" class="form-control"
                        placeholder="Enter Your Check In Day*" required>
                     
                      </div>
                      <div class="col-lg-6">
                      <input id="date2" data-provide="datepicker"  name="checkoutdate" type="text" placeholder="Enter Your Check Out Day*"
                        class="form-control" required>
                     
                      </div>

                      </div>
                      <div class="row">
                      <div class="col-lg-4">
                            <input class="form-control"  name="adult" type="number" placeholder="Adult*" />
                            </div>
                            <div class="col-lg-4">
                            <input class="form-control"  name="child" type="number" placeholder="Child*" />
                            </div>
                            <div class="col-lg-4">
                            <input class="form-control"   name="infant" type="number" placeholder="Infant*" />
                            </div>
                            </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-lg-12">
                      
                      <textarea id="story" name="msg" rows="1" class="form-control">Write something here.....</textarea>
                      </div>
                      <br>
                            <div class="col-lg-12">
                      
                      <input class="submit" type="submit" name="mailsent"  value="Submit">
                      </div>
                      </div>



    </form>
</div>
        </div>

        </div>
   
      
      
 <a href="#0" class="bts-popup-close img-replace">Close</a>
    </div>
</div>

    

  <!--  End Auto Load popup -->


</body>

<script>
	$(function() {
  var popup = $('#mainpopup');
  var time = $(".will-close strong");
  var closeSeconds = $("#mainpopup").attr("data-close");
  var openSeconds = $("#mainpopup").attr("data-open");
  var dataSrc = $("#mainpopup").attr("data-href");
  

  setTimeout(function(e) {
    
    popup.modal('show');
    time.html(closeSeconds);
    
    setInterval(function(){
      time.html(closeSeconds);
      closeSeconds--;
      
      if(closeSeconds < 0){
        popup.modal('hide');
      }
      
    }, 1000)
    
  }, openSeconds * 1000);
  
    $.ajax({
    url: dataSrc,
    dataType: "html",
    success: function(data) {
      $(".modal-body").html(data);
    }
  });
  
  
});
</script>
<!-- bootstrap js  -->
<script src="js/jquery.js"></script>
<script src="js/popper-min.js"></script>
<script src="js/bootstrap-min.js"></script>

<!-- swiper js  -->
<script src='js/swiper-min.js'></script>

<!-- owl-carousel js  -->
<script src="js/owl.carousel.min.js"></script>

<!-- choice select dropdown js  -->
<script src='js/choice-select-min.js'></script>

<!-- datepicker js  -->
<script src='js/datepicker.js'></script>

<!-- Aos js  -->
<script src="js/aos.js"></script>

<!-- custom js  -->
<script src="js/script.js"></script>


</html>